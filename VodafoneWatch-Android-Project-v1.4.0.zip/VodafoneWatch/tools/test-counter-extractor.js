'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const snapshotEvidence = require('./fixtures/vodafone-red-dom-evidence.json');

const workerPath = path.join(__dirname, '..', 'app', 'src', 'main', 'java', 'com', 'example', 'vfwatch', 'CheckWorker.kt');
const worker = fs.readFileSync(workerPath, 'utf8');
const match = worker.match(/const val JS = """([\s\S]*?)"""/);
assert.ok(match, 'Could not find embedded counter JavaScript in CheckWorker.kt');
const extractor = match[1];

function element(text, overrides = {}) {
  return Object.assign({
    innerText: text,
    textContent: text,
    children: [],
    value: '',
    getAttribute: () => '',
    nextElementSibling: null,
    parentElement: null,
    querySelector: () => null
  }, overrides);
}

function numberCard(number) {
  const numberNode = element(number);
  return element('', {
    querySelector(selector) {
      return selector === '.msisdn-item p' ? numberNode : null;
    },
    getAttribute(name) {
      return name === 'aria-label' ? `Select number ${number}` : '';
    }
  });
}

function execute({ selectorLists = {}, selectors = {}, leaves = [], cards = [], numbers = [], bodyText = '' } = {}) {
  const document = {
    body: element(bodyText),
    querySelectorAll(selector) {
      if (Object.hasOwn(selectorLists, selector)) return selectorLists[selector];
      if (Object.hasOwn(selectors, selector)) {
        const value = selectors[selector];
        return Array.isArray(value) ? value : value ? [value] : [];
      }
      if (selector === 'body *') return leaves;
      if (selector === '#red-panel vf-lines-pool .msisdn-item-container[role="button"]') return cards;
      if (selector === 'vf-lines-pool .msisdn-item-container[role="button"]') return cards;
      if (selector === 'vf-lines-pool .msisdn-item p' || selector === '.msisdn-item p') return numbers;
      return [];
    }
  };
  const raw = vm.runInNewContext(extractor, { document, Number, String, Array, parseInt, JSON });
  return raw ? JSON.parse(raw) : null;
}

const tests = [
  ['extracts real Vodafone snapshot structure and all 954 cards', () => {
    assert.equal(snapshotEvidence.counterSelector, 'vf-lines-pool .lines-count-footer .lines-numbers');
    assert.equal(snapshotEvidence.numberCardSelector, '#red-panel vf-lines-pool .msisdn-item-container[role="button"] .msisdn-item p');
    assert.equal(snapshotEvidence.loaded, snapshotEvidence.total);
    assert.equal(snapshotEvidence.numberCardElements, snapshotEvidence.total);
    assert.equal(snapshotEvidence.uniqueValidEgyptianMobileNumbers, snapshotEvidence.total);
    const counter = element(snapshotEvidence.counterText);
    const capturedCards = Array.from({ length: snapshotEvidence.numberCardElements }, (_, i) =>
      numberCard(`010${String(i).padStart(8, '0')}`)
    );
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: counter },
      cards: capturedCards
    });
    assert.equal(result.count, 954);
    assert.equal(result.loaded, 954);
    assert.equal(result.total, 954);
    assert.equal(result.source, snapshotEvidence.counterSelector);
    assert.equal(result.listSource, '#red-panel vf-lines-pool .msisdn-item-container[role="button"] .msisdn-item p');
    assert.equal(result.numberCardsCount, 954);
    assert.equal(result.numbersCount, 954);
    assert.equal(result.numbersComplete, true);
  }],
  ['accepts duplicate responsive counter nodes when their values agree', () => {
    const result = execute({
      selectorLists: {
        [snapshotEvidence.counterSelector]: [element('954 / 954'), element('954 / 954')]
      },
      cards: Array.from({ length: 954 }, (_, i) => numberCard(`010${String(i).padStart(8, '0')}`))
    });
    assert.equal(result.count, 954);
    assert.equal(result.numbersComplete, true);
  }],
  ['rejects conflicting duplicate counter readings', () => {
    const result = execute({
      selectorLists: {
        [snapshotEvidence.counterSelector]: [element('954 / 954'), element('953 / 954')]
      }
    });
    assert.match(result.error, /أكثر من قراءة مختلفة/);
  }],
  ['supports a legacy single counter fallback', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,779') } });
    assert.equal(result.count, 1779);
    assert.equal(result.mode, 'single');
    assert.equal(result.source, '#vf-lines-p');
  }],
  ['parses loaded / total pair', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,700 / 1,779') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
    assert.equal(result.mode, 'pair');
  }],
  ['normalizes Arabic-Indic digits and Arabic thousands separator', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('١٬٧٠٠ / ١٬٧٧٩') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
  }],
  ['fallback reads value adjacent to Arabic label', () => {
    const label = element('عدد الخطوط');
    label.nextElementSibling = element('١٬٧٧٩');
    const result = execute({ leaves: [label] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-adjacent');
  }],
  ['fallback parses English label with inline value', () => {
    const result = execute({ leaves: [element('Number of Lines: 1,779')] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-text');
  }],
  ['never infers the counter from phone numbers alone', () => {
    const result = execute({ numbers: [element('01012345678')] });
    assert.equal(result, null);
  }],
  ['detects error or verification screens', () => {
    const result = execute({ bodyText: 'حدث خطأ يرجى المحاولة مرة أخرى' });
    assert.match(result.error, /رسالة خطأ أو خطوة تحقق/);
  }],
  ['deduplicates valid values but marks duplicate cards incomplete', () => {
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: element('2 / 2') },
      cards: [numberCard('01012345678'), numberCard('01012345678')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678']);
    assert.equal(result.numberCardsCount, 2);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not treat a partial card list as complete', () => {
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: element('954 / 954') },
      cards: Array.from({ length: 953 }, (_, i) => numberCard(`010${String(i).padStart(8, '0')}`))
    });
    assert.equal(result.numberCardsCount, 953);
    assert.equal(result.numbersCount, 953);
    assert.equal(result.numbersComplete, false);
  }],
  ['rejects malformed and invalid Egyptian mobile prefixes', () => {
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: element('3 / 3') },
      cards: [numberCard('01012345678'), numberCard('01312345678'), numberCard('0101234567')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678']);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not compare a list when loaded and total differ', () => {
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: element('2 / 3') },
      cards: [numberCard('01012345678'), numberCard('01012345679')]
    });
    assert.equal(result.numbersComplete, false);
  }],
  ['supports paragraph fallback when interactive card wrappers change', () => {
    const result = execute({
      selectors: { [snapshotEvidence.counterSelector]: element('2 / 2') },
      numbers: [element('01012345678'), element('01012345679')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678', '01012345679']);
    assert.equal(result.numberCardsCount, 2);
    assert.equal(result.numbersComplete, true);
    assert.equal(result.listSource, 'vf-lines-pool .msisdn-item p');
  }],
  ['rejects a loaded count greater than the total', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('4 / 3') } });
    assert.equal(result, null);
  }]
];

for (const [name, test] of tests) {
  test();
  process.stdout.write(`PASS ${name}\n`);
}
process.stdout.write(`\n${tests.length} extractor tests passed.\n`);
