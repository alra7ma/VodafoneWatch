package com.example.vfwatch

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

class CheckWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {

    override suspend fun doWork(): Result {
        val result = withTimeoutOrNull(SCRAPE_TIMEOUT_MS) {
            withContext(Dispatchers.Main.immediate) { scrape() }
        }

        if (result == null) {
            saveFailure("انتهت مهلة انتظار تحميل صفحة فودافون")
            return Result.retry()
        }

        val pageError = result.optString("error", "").trim()
        if (pageError.isNotEmpty()) {
            saveFailure(pageError)
            return Result.retry()
        }

        val count = result.optInt("count", -1)
        val loaded = result.optInt("loaded", -1)
        val total = result.optInt("total", -1)
        val mode = result.optString("mode", "single")
        val source = result.optString("source", "غير محدد")
        if (count < 0 || loaded < 0 || total < 0) {
            saveFailure("لم يُعثر على قيمة صالحة لعداد Number of Lines")
            return Result.retry()
        }

        val numberArray = result.optJSONArray("numbers") ?: JSONArray()
        val numbers = LinkedHashSet<String>()
        for (i in 0 until numberArray.length()) {
            val number = numberArray.optString(i).filter(Char::isDigit)
            // أرقام المحمول المصرية ذات 11 خانة وبادئة تشغيل صحيحة فقط.
            if (Regex("^01[0125]\\d{8}$").matches(number)) numbers.add(number)
        }
        val numberCardsCount = result.optInt("numberCardsCount", -1)
        val listSource = result.optString("listSource", "غير محدد")

        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldCount = preferences.getInt("count", -1)
        val oldLoaded = preferences.getInt("loaded", -1)
        val oldTotal = preferences.getInt("total", -1)
        val oldMode = preferences.getString("counter_mode", "single") ?: "single"
        val oldNumbers = preferences.getStringSet("numbers", mutableSetOf())?.toSet() ?: emptySet()

        // لا نقارن قائمة الأرقام إلا بعد مطابقة قيمة العداد وعدد بطاقات DOM
        // وعدد الأرقام الصحيحة الفريدة. بنية DOM مأخوذة من ملف الصفحة المرفق.
        val completeNumberList = result.optBoolean("numbersComplete", false) &&
            mode == "pair" && total > 0 && loaded == total &&
            numberCardsCount == loaded && numbers.size == loaded
        val canCompareLists = completeNumberList && oldNumbers.isNotEmpty()
        val addedNumbers = if (canCompareLists) numbers.filter { it !in oldNumbers } else emptyList()
        val removedNumbers = if (canCompareLists) oldNumbers.filter { it !in numbers } else emptyList()

        val changes = mutableListOf<String>()
        if (oldCount >= 0) {
            when {
                mode == "pair" && oldMode == "pair" && oldLoaded >= 0 && oldTotal >= 0 &&
                    (oldLoaded != loaded || oldTotal != total) -> {
                    changes.add("تغيّر العداد: $oldLoaded / $oldTotal ← $loaded / $total")
                }
                mode == "pair" && oldMode != "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count ($loaded / $total)")
                }
                mode != "pair" && oldMode == "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count")
                }
                mode != "pair" && oldMode != "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count")
                }
            }
        }
        if (addedNumbers.isNotEmpty()) {
            changes.add("أرقام جديدة (+${addedNumbers.size}): ${addedNumbers.take(8).joinToString("، ")}")
        }
        if (removedNumbers.isNotEmpty()) {
            changes.add("أرقام لم تعد ظاهرة (-${removedNumbers.size}): ${removedNumbers.take(8).joinToString("، ")}")
        }

        val now = System.currentTimeMillis()
        val history = readHistory(preferences)
        history.put(
            JSONObject()
                .put("time", now)
                .put("ok", true)
                .put("count", count)
                .put("loaded", loaded)
                .put("total", total)
                .put("mode", mode)
                .put("source", source)
                .put("list_source", listSource)
                .put("number_cards", numberCardsCount)
                .put("numbers", numbers.size)
                .put("numbers_complete", completeNumberList)
                .put("added", addedNumbers.size)
                .put("removed", removedNumbers.size)
                .put("added_numbers", JSONArray().apply { addedNumbers.forEach { put(it) } })
                .put("removed_numbers", JSONArray().apply { removedNumbers.forEach { put(it) } })
                .put("change", changes.joinToString(" | "))
        )
        trimHistory(history)

        val editor = preferences.edit()
            .putInt("count", count)
            .putInt("loaded", loaded)
            .putInt("total", total)
            .putString("counter_mode", mode)
            .putString("source", source)
            .putLong("time", now)
            .putLong("attempt_time", now)
            .putBoolean("last_ok", true)
            .putString("error", "")
            .putString("history", history.toString())
            .putInt("number_count", numbers.size)
            .putInt("number_cards_count", numberCardsCount)
            .putString("list_source", listSource)
            .putBoolean("number_list_complete", completeNumberList)
        if (completeNumberList) {
            editor.putStringSet("numbers", numbers.toMutableSet())
            editor.putString("numbers_json", JSONArray().apply { numbers.forEach { put(it) } }.toString())
            editor.putInt("saved_number_count", numbers.size)
            editor.putLong("number_updated_time", now)
        }
        editor.apply()

        if (changes.isNotEmpty()) notifyChange(changes.joinToString("\n"))
        return Result.success()
    }

    private fun saveFailure(message: String) {
        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val history = readHistory(preferences)
        history.put(JSONObject().put("time", now).put("ok", false).put("error", message))
        trimHistory(history)
        preferences.edit()
            .putBoolean("last_ok", false)
            .putString("error", message)
            .putLong("attempt_time", now)
            .putString("history", history.toString())
            .apply()
    }

    private fun readHistory(contextPreferences: android.content.SharedPreferences): JSONArray = try {
        JSONArray(contextPreferences.getString("history", "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun trimHistory(history: JSONArray) {
        while (history.length() > MAX_HISTORY_ITEMS) history.remove(0)
    }

    private suspend fun scrape(): JSONObject? = suspendCancellableCoroutine { continuation ->
        val handler = Handler(Looper.getMainLooper())
        val webView = try {
            WebView(applicationContext)
        } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        var lastPayload = ""
        var stableCount = 0
        var attempts = 0
        var finished = false
        var pageLoadError = ""

        fun finish(value: JSONObject?) {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            try {
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
                // The WebView may already have been torn down after cancellation.
            }
            if (continuation.isActive) continuation.resume(value)
        }

        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                if (pageLoadError.isNotBlank()) {
                    finish(JSONObject().put("error", pageLoadError))
                    return
                }
                try {
                    webView.evaluateJavascript(JS) { raw ->
                        if (finished) return@evaluateJavascript
                        val payload = try {
                            val decoded = JSONTokener(raw ?: "null").nextValue()
                            decoded as? String ?: ""
                        } catch (_: Exception) {
                            ""
                        }
                        attempts++
                        stableCount = if (payload.isNotBlank() && payload == lastPayload) stableCount + 1 else 0
                        lastPayload = payload

                        when {
                            stableCount >= STABLE_READS_REQUIRED -> {
                                val parsed = try { JSONObject(payload) } catch (_: Exception) { null }
                                val waitingForFullInventory = parsed != null &&
                                    parsed.optString("mode") == "pair" &&
                                    parsed.optInt("total", 0) > 0 &&
                                    !parsed.optBoolean("numbersComplete", false)
                                if (waitingForFullInventory && attempts < MAX_POLL_ATTEMPTS) {
                                    // قد يظهر العداد قبل اكتمال رسم بطاقات الأرقام في Angular؛
                                    // استمر في الفحص حتى تكتمل القائمة أو تنتهي مهلة المحاولات.
                                    handler.postDelayed(this, POLL_INTERVAL_MS)
                                } else {
                                    finish(parsed)
                                }
                            }
                            attempts >= MAX_POLL_ATTEMPTS -> finish(null)
                            else -> handler.postDelayed(this, POLL_INTERVAL_MS)
                        }
                    }
                } catch (_: Exception) {
                    finish(null)
                }
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = false
        webView.settings.blockNetworkImage = true
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.settings.safeBrowsingEnabled = true
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                handler.removeCallbacks(poll)
                handler.postDelayed(poll, INITIAL_POLL_DELAY_MS)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    pageLoadError = "تعذّر تحميل صفحة فودافون بسبب خطأ اتصال."
                }
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    pageLoadError = "رفض خادم فودافون تحميل الصفحة (HTTP ${errorResponse?.statusCode})."
                }
            }
        }

        continuation.invokeOnCancellation {
            handler.post {
                handler.removeCallbacksAndMessages(null)
                try {
                    webView.stopLoading()
                    webView.destroy()
                } catch (_: Exception) {
                    // Ignore teardown errors during worker cancellation.
                }
            }
        }

        try {
            webView.loadUrl(PAGE)
        } catch (_: Exception) {
            finish(null)
        }
    }

    private fun notifyChange(message: String) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "مراقبة فودافون RED", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("تغيّر في أرقام فودافون RED")
            .setContentText(message.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Notifications are unavailable until the user grants permission.
        }
    }

    companion object {
        const val PREFS = "vf"
        const val PERIODIC_WORK = "vf-watch"
        const val MANUAL_WORK = "vf-manual-check"
        const val CHANNEL_ID = "vf_watch_changes"
        const val NOTIFICATION_ID = 701

        const val PAGE = "https://eshop.vodafone.com.eg/en/lines/red/numbers?channelId=REDPlanAR&c_id=DACS0335&c_medium=PPC&c_name=REDPlanAR&c_source=Search&c_term=REDPlanAR&c_type=Anonymous"

        private const val SCRAPE_TIMEOUT_MS = 110_000L
        private const val INITIAL_POLL_DELAY_MS = 2_000L
        private const val POLL_INTERVAL_MS = 1_500L
        private const val MAX_POLL_ATTEMPTS = 55
        private const val STABLE_READS_REQUIRED = 2
        private const val MAX_HISTORY_ITEMS = 40

        // يبدأ الاستخراج بمحدد العداد الفعلي المثبت في ملف صفحة فودافون المرفق.
        // تبقى المحددات القديمة بدائل احتياطية فقط عند تغيّر بنية الموقع.
        const val JS = """(function(){
          function asciiDigits(value){
            return String(value == null ? '' : value)
              .replace(/[٠-٩]/g, function(ch){ return String(ch.charCodeAt(0) - 1632); })
              .replace(/[۰-۹]/g, function(ch){ return String(ch.charCodeAt(0) - 1776); })
              .replace(/[٬]/g, ',');
          }
          function cleanText(el){
            if(!el) return '';
            var raw = el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
            return asciiDigits(raw).replace(/\s+/g,' ').trim();
          }
          function parseCounterText(raw, afterLabelOnly){
            var text = asciiDigits(raw).replace(/\s+/g,' ').trim();
            if(!text) return null;
            var label = /(?:number\s+of\s+lines|عدد\s+الخطوط)/i;
            var labelMatch = label.exec(text);
            if(labelMatch){
              var after = text.slice(labelMatch.index + labelMatch[0].length);
              var afterValues = after.match(/\d[\d,]*/g) || [];
              if(afterValues.length){ text = after; }
              else if(afterLabelOnly){
                var before = text.slice(0, labelMatch.index);
                var beforeValues = before.match(/\d[\d,]*/g) || [];
                if(beforeValues.length === 1) text = before;
                else return null;
              }
            } else if(afterLabelOnly) {
              return null;
            }
            var pair = text.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)/);
            var values = text.match(/\d[\d,]*/g) || [];
            function asInt(v){ return parseInt(String(v).replace(/,/g,''),10); }
            var mode = 'single', loaded, total, count;
            if(pair){
              loaded = asInt(pair[1]);
              total = asInt(pair[2]);
              count = total;
              mode = 'pair';
            } else if(values.length){
              count = asInt(values[values.length - 1]);
              loaded = count;
              total = count;
            } else return null;
            if(!Number.isFinite(count) || count < 0 || loaded > total) return null;
            return {count:count, loaded:loaded, total:total, mode:mode};
          }
          function queryAll(selector){
            try { return Array.prototype.slice.call(document.querySelectorAll(selector) || []); }
            catch(e) { return []; }
          }
          function sameValue(a,b){
            return a && b && a.mode === b.mode && a.loaded === b.loaded && a.total === b.total;
          }

          // Exact counter selector from the saved Vodafone DOM (23 Nov 2026).
          // Responsive duplicates are accepted only when all readings agree.
          var counterSelectors = [
            'vf-lines-pool .lines-count-footer .lines-numbers',
            '#red-panel vf-lines-pool .lines-count-footer .lines-numbers',
            '.lines-count-footer .lines-numbers',
            '#vf-lines-p',
            '[data-testid="vf-lines-p"]',
            '[data-cy="vf-lines-p"]',
            '.vf-lines-p',
            'vf-lines-p',
            '[id*="vf-lines-p"]',
            '[data-testid*="lines"]',
            '.lines-numbers'
          ];
          var parsed = null;
          var counterSource = '';
          for(var i=0; i<counterSelectors.length && !parsed; i++){
            var counterNodes = queryAll(counterSelectors[i]);
            if(!counterNodes.length) continue;
            var readings = [];
            counterNodes.forEach(function(node){
              var value = parseCounterText(cleanText(node), false);
              if(!value){
                var attrValue = node.getAttribute('data-value') || node.value || node.getAttribute('aria-label') || '';
                value = parseCounterText(attrValue, false);
              }
              if(value) readings.push(value);
            });
            if(readings.length){
              parsed = readings[0];
              counterSource = counterSelectors[i];
              for(var r=1; r<readings.length; r++){
                if(!sameValue(parsed, readings[r])){
                  return JSON.stringify({error:'ظهرت أكثر من قراءة مختلفة لعداد Number of Lines؛ أُوقف الحفظ لتجنب اعتماد قيمة ملتبسة.'});
                }
              }
            }
          }

          // Fallback: inspect only the value adjacent to the counter label.
          if(!parsed){
            var labelPattern = /^(?:number\s+of\s+lines|عدد\s+الخطوط)(?:\s*[:：-]?\s*[\d,]+(?:\s*\/\s*[\d,]+)?)?$/i;
            var leaves = queryAll('body *');
            for(var j=0; j<leaves.length && !parsed; j++){
              var el = leaves[j];
              if(el.children && el.children.length) continue;
              var labelText = cleanText(el);
              if(!labelPattern.test(labelText)) continue;
              parsed = parseCounterText(labelText, true);
              if(parsed){ counterSource = 'label-text'; break; }
              var adjacent = [el.nextElementSibling, el.parentElement, el.parentElement && el.parentElement.nextElementSibling];
              for(var k=0; k<adjacent.length && !parsed; k++){
                var candidate = adjacent[k];
                if(!candidate) continue;
                parsed = parseCounterText(cleanText(candidate), false);
                if(parsed){ counterSource = 'label-adjacent'; break; }
              }
            }
          }
          if(!parsed){
            var bodyText = cleanText(document.body).toLowerCase();
            if(/captcha|access denied|cloudflare|حدث خطأ|يرجى المحاولة|يرجى المحاوله/.test(bodyText)){
              return JSON.stringify({error:'تعذّرت قراءة صفحة فودافون: ظهرت رسالة خطأ أو خطوة تحقق بدل بيانات العداد.'});
            }
            return '';
          }

          function onlyDigits(value){ return asciiDigits(value).replace(/\D/g,''); }
          function validEgyptianMobile(value){ return /^01[0125]\d{8}$/.test(value); }

          // Exact interactive card structure in the saved #red-panel.
          var cardSelector = '#red-panel vf-lines-pool .msisdn-item-container[role="button"]';
          var cards = queryAll(cardSelector);
          var listSource = cardSelector + ' .msisdn-item p';
          if(!cards.length){
            cardSelector = 'vf-lines-pool .msisdn-item-container[role="button"]';
            cards = queryAll(cardSelector);
            listSource = cardSelector + ' .msisdn-item p';
          }
          var phoneNumbers = [];
          if(cards.length){
            cards.forEach(function(card){
              var valueNode = null;
              try { valueNode = card.querySelector('.msisdn-item p'); } catch(e) {}
              var value = valueNode ? cleanText(valueNode) : (card.getAttribute('aria-label') || '');
              var digits = onlyDigits(value);
              if(validEgyptianMobile(digits)) phoneNumbers.push(digits);
            });
          } else {
            var numberElements = queryAll('vf-lines-pool .msisdn-item p');
            listSource = 'vf-lines-pool .msisdn-item p';
            if(!numberElements.length){
              numberElements = queryAll('.msisdn-item p');
              listSource = '.msisdn-item p';
            }
            cards = numberElements;
            numberElements.forEach(function(el){
              var digits = onlyDigits(cleanText(el));
              if(validEgyptianMobile(digits)) phoneNumbers.push(digits);
            });
          }
          var uniqueNumbers = Array.from(new Set(phoneNumbers));
          var cardCount = cards.length;
          var numbersComplete = parsed.mode === 'pair' &&
            parsed.loaded === parsed.total && parsed.total > 0 &&
            cardCount === parsed.loaded && uniqueNumbers.length === parsed.loaded;
          return JSON.stringify({
            count: parsed.count,
            loaded: parsed.loaded,
            total: parsed.total,
            mode: parsed.mode,
            source: counterSource || 'label-fallback',
            listSource: listSource,
            numberCardsCount: cardCount,
            numbersCount: uniqueNumbers.length,
            numbersComplete: numbersComplete,
            numbers: uniqueNumbers
          });
        })()"""
    }
}
