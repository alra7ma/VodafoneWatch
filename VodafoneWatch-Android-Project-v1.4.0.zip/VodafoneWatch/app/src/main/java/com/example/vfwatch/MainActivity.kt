package com.example.vfwatch

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.InputType
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(CheckWorker.PREFS, Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var counterCaption: TextView
    private lateinit var lastCheck: TextView
    private lateinit var history: TextView
    private lateinit var inventoryStatus: TextView
    private lateinit var numberQuery: EditText
    private lateinit var numberResults: TextView
    private lateinit var monitorButton: Button
    private var latestSearchResults: List<String> = emptyList()
    private val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        buildScreen()
        render()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(Color.rgb(247, 248, 250))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }

        page.addView(label("VODAFONE WATCH", 13, Color.rgb(210, 25, 45), true))
        page.addView(label("مراقبة أرقام RED", 27, Color.rgb(28, 34, 43), true).apply {
            setPadding(0, dp(5), 0, dp(5))
        })
        page.addView(label("متابعة عدّاد Number of Lines واكتشاف التغيّرات", 14, Color.DKGRAY, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(Color.WHITE)
            elevation = dp(2).toFloat()
        }
        page.addView(card, topMargin(22))

        status = label("● في انتظار أول فحص", 14, Color.GRAY, true)
        card.addView(status)
        counter = label("—", 38, Color.rgb(35, 40, 48), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(4))
        }
        card.addView(counter)
        counterCaption = label("قيمة العداد", 13, Color.GRAY, false).apply {
            gravity = Gravity.CENTER
        }
        card.addView(counterCaption)
        lastCheck = label("لم يُنفّذ أي فحص بعد", 13, Color.DKGRAY, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        card.addView(lastCheck)

        page.addView(actionButton("افحص الآن", true) { runManualCheck() }, topMargin(18))
        monitorButton = actionButton("ابدأ المراقبة كل 15 دقيقة", false) { startMonitoring() }
        page.addView(monitorButton, topMargin(10))
        page.addView(actionButton("إيقاف المراقبة", false) { stopMonitoring() }, topMargin(10))
        page.addView(actionButton("فتح صفحة اختيار أرقام RED الرسمية", false) { openVodafonePage() }, topMargin(10))

        page.addView(sectionTitle("قائمة الأرقام المتاحة"), topMargin(25))
        inventoryStatus = label("لم تُقرأ قائمة مكتملة بعد.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(inventoryStatus, topMargin(8))
        numberQuery = EditText(this).apply {
            hint = "ابحث بجزء من الرقم أو تسلسل الأرقام"
            inputType = InputType.TYPE_CLASS_NUMBER
            textDirection = View.TEXT_DIRECTION_LTR
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(numberQuery, topMargin(8))
        page.addView(actionButton("ابحث في القائمة المحفوظة", true) { searchSavedNumbers() }, topMargin(8))
        page.addView(actionButton("نسخ نتائج البحث", false) { copySearchResults() }, topMargin(8))
        numberResults = label("أدخل رقمًا أو تسلسلًا من رقمين على الأقل لبدء البحث.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
            textDirection = View.TEXT_DIRECTION_LTR
        }
        page.addView(numberResults, topMargin(8))

        page.addView(sectionTitle("سجل آخر الفحوصات"), topMargin(25))
        history = label("لا توجد سجلات بعد.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(history, topMargin(8))
        page.addView(
            label(
                "ملاحظة: الفحص الدوري مضبوط على الحد الأدنى الذي يسمح به أندرويد (15 دقيقة)، وقد يتأخر التنفيذ لتوفير البطارية أو عند انقطاع الإنترنت.",
                12,
                Color.GRAY,
                false
            ).apply { setPadding(0, dp(18), 0, 0) }
        )
        setContentView(scroll)
    }

    private fun render() {
        val loaded = prefs.getInt("loaded", -1)
        val total = prefs.getInt("total", -1)
        val count = prefs.getInt("count", -1)
        val mode = prefs.getString("counter_mode", "single") ?: "single"
        val successTime = prefs.getLong("time", 0L)
        val attemptTime = prefs.getLong("attempt_time", 0L)
        val ok = prefs.getBoolean("last_ok", true)
        val error = prefs.getString("error", "") ?: ""
        val source = prefs.getString("source", "") ?: ""
        val numberCount = prefs.getInt("number_count", 0)
        val numberCardsCount = prefs.getInt("number_cards_count", 0)
        val numberListComplete = prefs.getBoolean("number_list_complete", false)
        val numberUpdatedTime = prefs.getLong("number_updated_time", 0L)
        val running = prefs.getBoolean("monitoring", false)

        status.text = when {
            !ok -> "● تعذّر آخر فحص"
            successTime == 0L -> "● في انتظار أول فحص"
            else -> "● آخر فحص ناجح"
        }
        status.setTextColor(if (!ok) Color.rgb(190, 70, 45) else Color.rgb(35, 145, 85))

        counter.text = when {
            mode == "pair" && loaded >= 0 && total >= 0 -> "$loaded / $total"
            count >= 0 -> count.toString()
            total >= 0 -> total.toString()
            else -> "—"
        }
        counterCaption.text = if (mode == "pair") {
            "عدد الأرقام المحمّلة / العدد الإجمالي"
        } else {
            "قيمة عدّاد Number of Lines"
        }

        val dateLine = if (successTime > 0L) "آخر قراءة ناجحة: ${formatDate(successTime)}" else "لا توجد قراءة ناجحة محفوظة"
        val attemptLine = if (attemptTime > 0L) "آخر محاولة: ${formatDate(attemptTime)}" else ""
        lastCheck.text = listOfNotNull(
            dateLine,
            attemptLine.takeIf { it.isNotBlank() },
            ("مصدر القراءة: $source").takeIf { successTime > 0L && source.isNotBlank() },
            ("الأرقام المقروءة: $numberCount من $numberCardsCount بطاقة" + if (numberListComplete) " (قائمة مكتملة)" else " (قائمة غير مكتملة؛ لن تُقارن الأرقام)")
                .takeIf { successTime > 0L },
            ("مصدر قائمة الأرقام: ${prefs.getString("list_source", "غير محدد") ?: "غير محدد"}")
                .takeIf { successTime > 0L && prefs.contains("list_source") },
            error.takeIf { !ok && it.isNotBlank() }
        ).joinToString("\n")

        monitorButton.text = if (running) "المراقبة مفعّلة — كل 15 دقيقة" else "ابدأ المراقبة كل 15 دقيقة"
        inventoryStatus.text = when {
            numberListComplete && numberUpdatedTime > 0L && !ok ->
                "آخر قائمة ناجحة محفوظة: ${prefs.getInt("saved_number_count", numberCount)} رقمًا\nتاريخها: ${formatDate(numberUpdatedTime)}\nآخر محاولة فحص لم تنجح؛ هذه البيانات هي آخر لقطة مكتملة وليست تأكيدًا للحالة الحالية."
            numberListComplete && numberUpdatedTime > 0L ->
                "قائمة مكتملة: $numberCount رقمًا فريدًا من $numberCardsCount بطاقة\nآخر تحديث للقائمة: ${formatDate(numberUpdatedTime)}\nالمصدر: ${prefs.getString("list_source", "غير محدد") ?: "غير محدد"}"
            successTime > 0L ->
                "العداد قُرئ، لكن قائمة الأرقام الأخيرة غير مكتملة ($numberCount رقمًا من $numberCardsCount بطاقة). لن تُستخدم للمقارنة أو البحث."
            else -> "لم تُقرأ قائمة مكتملة بعد. نفّذ فحصًا ناجحًا للبدء."
        }
        history.text = renderHistory()
    }

    private fun renderHistory(): String {
        val data = try {
            JSONArray(prefs.getString("history", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        if (data.length() == 0) return "لا توجد سجلات بعد."

        val lines = mutableListOf<String>()
        for (i in data.length() - 1 downTo maxOf(0, data.length() - 8)) {
            val item = data.optJSONObject(i) ?: continue
            val time = formatDate(item.optLong("time"))
            if (!item.optBoolean("ok", true)) {
                lines.add("$time  •  تعذّر الفحص: ${item.optString("error")}")
                continue
            }
            val value = if (item.optString("mode") == "pair") {
                "${item.optInt("loaded")} / ${item.optInt("total")}"
            } else {
                item.optInt("count").toString()
            }
            val change = item.optString("change")
            val listedNumbers = item.optInt("numbers", -1)
            val listState = if (item.optBoolean("numbers_complete", false)) "قائمة كاملة" else "قائمة غير مكتملة"
            val cardCount = item.optInt("number_cards", -1)
            val cardLine = if (cardCount >= 0) "، $cardCount بطاقة" else ""
            val listLine = if (listedNumbers >= 0) "\n$listedNumbers رقمًا$cardLine — $listState" else ""
            lines.add("$time  •  $value$listLine" + if (change.isNotBlank()) "\n$change" else "")
        }
        return lines.joinToString("\n\n")
    }

    private fun runManualCheck() {
        val request = OneTimeWorkRequestBuilder<CheckWorker>()
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            CheckWorker.MANUAL_WORK,
            ExistingWorkPolicy.KEEP,
            request
        )
        Toast.makeText(this, "بدأ الفحص؛ انتظر ظهور نتيجة القراءة", Toast.LENGTH_LONG).show()
    }

    private fun startMonitoring() {
        val request = PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            CheckWorker.PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
        prefs.edit().putBoolean("monitoring", true).apply()
        // نفّذ قراءة تأسيسية فورًا بدل انتظار أول دورة كاملة (15 دقيقة).
        val initialCheck = OneTimeWorkRequestBuilder<CheckWorker>()
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            CheckWorker.MANUAL_WORK,
            ExistingWorkPolicy.KEEP,
            initialCheck
        )
        Toast.makeText(this, "تم تفعيل المراقبة وبدء فحص تأسيسي", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun stopMonitoring() {
        WorkManager.getInstance(this).cancelUniqueWork(CheckWorker.PERIODIC_WORK)
        prefs.edit().putBoolean("monitoring", false).apply()
        Toast.makeText(this, "تم إيقاف المراقبة الدورية", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun loadSavedNumbers(): List<String> {
        if (!prefs.getBoolean("number_list_complete", false)) return emptyList()
        val stored = prefs.getString("numbers_json", null)
        if (!stored.isNullOrBlank()) {
            return try {
                val array = JSONArray(stored)
                (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }
            } catch (_: Exception) {
                emptyList()
            }
        }
        // Compatibility with earlier versions that saved a StringSet only.
        return prefs.getStringSet("numbers", emptySet())?.toList()?.sorted().orEmpty()
    }

    private fun normalizeDigits(value: String): String = buildString {
        value.forEach { ch ->
            val normalized = when (ch) {
                in '\u0660'..'\u0669' -> ('0'.code + ch.code - '\u0660'.code).toChar()
                in '\u06F0'..'\u06F9' -> ('0'.code + ch.code - '\u06F0'.code).toChar()
                else -> ch
            }
            if (normalized in '0'..'9') append(normalized)
        }
    }

    private fun searchSavedNumbers() {
        if (!prefs.getBoolean("number_list_complete", false)) {
            latestSearchResults = emptyList()
            numberResults.text = "لا يمكن البحث الآن؛ آخر قائمة لم تكن مكتملة. نفّذ فحصًا جديدًا وانتظر اكتمال القائمة."
            return
        }
        val query = normalizeDigits(numberQuery.text?.toString().orEmpty())
        if (query.length < 2) {
            latestSearchResults = emptyList()
            numberResults.text = "أدخل رقمين على الأقل لتضييق النتائج."
            return
        }
        val numbers = loadSavedNumbers()
        latestSearchResults = numbers.filter { it.contains(query) }
        numberResults.text = if (latestSearchResults.isEmpty()) {
            "لا توجد أرقام تحتوي على التسلسل $query."
        } else {
            val visible = latestSearchResults.take(MAX_VISIBLE_SEARCH_RESULTS)
            "عدد النتائج: ${latestSearchResults.size}\n" +
                visible.joinToString("\n") +
                if (latestSearchResults.size > visible.size) "\n\nيُعرض أول ${visible.size} فقط؛ زر النسخ ينسخ جميع النتائج." else ""
        }
        numberResults.textDirection = View.TEXT_DIRECTION_LTR
    }

    private fun copySearchResults() {
        if (latestSearchResults.isEmpty()) {
            Toast.makeText(this, "لا توجد نتائج لنسخها", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Vodafone RED search results", latestSearchResults.joinToString("\n")))
        Toast.makeText(this, "تم نسخ ${latestSearchResults.size} رقمًا", Toast.LENGTH_SHORT).show()
    }

    private fun openVodafonePage() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(CheckWorker.PAGE)))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذّر فتح صفحة فودافون", Toast.LENGTH_LONG).show()
        }
    }

    private fun networkConstraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_PERMISSION_REQUEST
            )
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

    private fun sectionTitle(text: String) = label(text, 17, Color.rgb(35, 40, 48), true)

    private fun actionButton(text: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setTextColor(if (primary) Color.WHITE else Color.rgb(175, 20, 40))
        if (Build.VERSION.SDK_INT >= 21) {
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (primary) Color.rgb(210, 25, 45) else Color.WHITE
            )
        }
        setOnClickListener { action() }
    }

    private fun topMargin(value: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(value)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun formatDate(time: Long) = SimpleDateFormat(
        "dd/MM/yyyy  HH:mm:ss",
        Locale.getDefault()
    ).format(Date(time))

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        render()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    companion object {
        private const val NOTIFICATION_PERMISSION_REQUEST = 100
        private const val MAX_VISIBLE_SEARCH_RESULTS = 100
    }
}
