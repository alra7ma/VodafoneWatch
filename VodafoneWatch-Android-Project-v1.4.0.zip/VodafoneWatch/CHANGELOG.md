# Changelog

## 1.4.0 — 25 November 2026

- Corrected the primary Number of Lines selector to match the original MHTML DOM.
- Scoped number-card extraction to the visible RED panel and interactive card containers.
- Added counter ambiguity detection when responsive copies disagree.
- Added longer polling for Angular inventory cards when the count appears before the full card list.
- Tightened mobile-number validation and full-list completeness checks.
- Added detection and history persistence for both added and removed numbers.
- Added in-app sequence search, result copying, and a shortcut to the official Vodafone RED page.
- Hardened WebView settings and captured main-frame connection/HTTP errors.
- Updated CI to install Android SDK packages before building the APK.
