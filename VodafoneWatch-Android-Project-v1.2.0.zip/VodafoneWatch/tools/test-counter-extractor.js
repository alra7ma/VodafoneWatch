'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const workerPath = path.join(__dirname, '..', 'app', 'src', 'main', 'java', 'com', 'example', 'vfwatch', 'CheckWorker.kt');
const worker = fs.readFileSync(workerPath, 'utf8');
const match = worker.match(/const val JS = """([\s\S]*?)"""/);
assert.ok(match, 'Could not find embedded counter JavaScript in CheckWorker.kt');
const extractor = match[1];

function element(text, overrides = {}) {
  return Object.assign({
    innerText: text,
    textContent: text,
    children: [],
    value: '',
    getAttribute: () => '',
    nextElementSibling: null,
    parentElement: null
  }, overrides);
}

function execute({ selectors = {}, leaves = [], numbers = [], bodyText = '' } = {}) {
  const document = {
    body: element(bodyText),
    querySelector(selector) {
      return selectors[selector] || null;
    },
    querySelectorAll(selector) {
      if (selector === 'body *') return leaves;
      if (selector === '.msisdn-item p, .msisdn-item') return numbers;
      return [];
    }
  };
  const raw = vm.runInNewContext(extractor, { document, Number, String, Array, parseInt, JSON });
  return raw ? JSON.parse(raw) : null;
}

const tests = [
  ['single counter from #vf-lines-p', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,779') } });
    assert.equal(result.count, 1779);
    assert.equal(result.mode, 'single');
    assert.equal(result.source, '#vf-lines-p');
  }],
  ['loaded / total pair', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,700 / 1,779') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
    assert.equal(result.mode, 'pair');
  }],
  ['Arabic-Indic digits and Arabic thousands separator', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('١٬٧٠٠ / ١٬٧٧٩') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
  }],
  ['fallback from Arabic label to adjacent value', () => {
    const label = element('عدد الخطوط');
    label.nextElementSibling = element('١٬٧٧٩');
    const result = execute({ leaves: [label] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-adjacent');
  }],
  ['fallback from English inline label', () => {
    const result = execute({ leaves: [element('Number of Lines: 1,779')] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-text');
  }],
  ['never infer the counter from phone numbers', () => {
    const result = execute({ numbers: [element('01012345678')] });
    assert.equal(result, null);
  }],
  ['detect page error / verification screen', () => {
    const result = execute({ bodyText: 'حدث خطأ يرجى المحاولة مرة أخرى' });
    assert.match(result.error, /رسالة خطأ أو خطوة تحقق/);
  }],
  ['deduplicate visible MSISDN values', () => {
    const result = execute({
      selectors: { '#vf-lines-p': element('1,779') },
      numbers: [element('01012345678'), element('01012345678'), element('01012345679')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678', '01012345679']);
  }]
];

for (const [name, test] of tests) {
  test();
  process.stdout.write(`PASS ${name}\n`);
}
process.stdout.write(`\n${tests.length} extractor tests passed.\n`);
