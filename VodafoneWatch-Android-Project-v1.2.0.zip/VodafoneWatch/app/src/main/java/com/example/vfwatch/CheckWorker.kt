package com.example.vfwatch

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

class CheckWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {

    override suspend fun doWork(): Result {
        val result = withTimeoutOrNull(SCRAPE_TIMEOUT_MS) {
            withContext(Dispatchers.Main.immediate) { scrape() }
        }

        if (result == null) {
            saveFailure("انتهت مهلة انتظار تحميل صفحة فودافون")
            return Result.retry()
        }

        val pageError = result.optString("error", "").trim()
        if (pageError.isNotEmpty()) {
            saveFailure(pageError)
            return Result.retry()
        }

        val count = result.optInt("count", -1)
        val loaded = result.optInt("loaded", -1)
        val total = result.optInt("total", -1)
        val mode = result.optString("mode", "single")
        val source = result.optString("source", "غير محدد")
        if (count < 0 || loaded < 0 || total < 0) {
            saveFailure("لم يُعثر على قيمة صالحة لعداد Number of Lines")
            return Result.retry()
        }

        val numberArray = result.optJSONArray("numbers") ?: JSONArray()
        val numbers = LinkedHashSet<String>()
        for (i in 0 until numberArray.length()) {
            val number = numberArray.optString(i).filter(Char::isDigit)
            if (number.length in 10..15) numbers.add(number)
        }

        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldCount = preferences.getInt("count", -1)
        val oldLoaded = preferences.getInt("loaded", -1)
        val oldTotal = preferences.getInt("total", -1)
        val oldMode = preferences.getString("counter_mode", "single") ?: "single"
        val oldNumbers = preferences.getStringSet("numbers", mutableSetOf())?.toSet() ?: emptySet()

        // لا نحفظ مجموعة الأرقام إلا إذا كانت جميع الأرقام المعلنة ظاهرة في DOM.
        // هذا يمنع استنتاج أرقام جديدة من قائمة جزئية أو صفحة نتائج مقسّمة.
        val completeNumberList = total > 0 && numbers.size >= total
        val addedNumbers = if (completeNumberList && oldNumbers.isNotEmpty()) {
            numbers.filter { it !in oldNumbers }
        } else {
            emptyList()
        }

        val changes = mutableListOf<String>()
        if (oldCount >= 0) {
            when {
                mode == "pair" && oldMode == "pair" && oldLoaded >= 0 && oldTotal >= 0 &&
                    (oldLoaded != loaded || oldTotal != total) -> {
                    changes.add("تغيّر العداد: $oldLoaded / $oldTotal ← $loaded / $total")
                }
                mode == "pair" && oldMode != "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count ($loaded / $total)")
                }
                mode != "pair" && oldMode == "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count")
                }
                mode != "pair" && oldMode != "pair" && oldCount != count -> {
                    changes.add("تغيّرت قيمة العداد: $oldCount ← $count")
                }
            }
        }
        if (addedNumbers.isNotEmpty()) {
            changes.add("أرقام جديدة: ${addedNumbers.take(8).joinToString("، ")}")
        }

        val now = System.currentTimeMillis()
        val history = readHistory(preferences)
        history.put(
            JSONObject()
                .put("time", now)
                .put("ok", true)
                .put("count", count)
                .put("loaded", loaded)
                .put("total", total)
                .put("mode", mode)
                .put("source", source)
                .put("numbers", numbers.size)
                .put("change", changes.joinToString(" | "))
        )
        trimHistory(history)

        val editor = preferences.edit()
            .putInt("count", count)
            .putInt("loaded", loaded)
            .putInt("total", total)
            .putString("counter_mode", mode)
            .putString("source", source)
            .putLong("time", now)
            .putLong("attempt_time", now)
            .putBoolean("last_ok", true)
            .putString("error", "")
            .putString("history", history.toString())
            .putInt("number_count", numbers.size)
        if (completeNumberList) editor.putStringSet("numbers", numbers.toMutableSet())
        editor.apply()

        if (changes.isNotEmpty()) notifyChange(changes.joinToString("\n"))
        return Result.success()
    }

    private fun saveFailure(message: String) {
        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val history = readHistory(preferences)
        history.put(JSONObject().put("time", now).put("ok", false).put("error", message))
        trimHistory(history)
        preferences.edit()
            .putBoolean("last_ok", false)
            .putString("error", message)
            .putLong("attempt_time", now)
            .putString("history", history.toString())
            .apply()
    }

    private fun readHistory(contextPreferences: android.content.SharedPreferences): JSONArray = try {
        JSONArray(contextPreferences.getString("history", "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun trimHistory(history: JSONArray) {
        while (history.length() > MAX_HISTORY_ITEMS) history.remove(0)
    }

    private suspend fun scrape(): JSONObject? = suspendCancellableCoroutine { continuation ->
        val handler = Handler(Looper.getMainLooper())
        val webView = try {
            WebView(applicationContext)
        } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        var lastPayload = ""
        var stableCount = 0
        var attempts = 0
        var finished = false

        fun finish(value: JSONObject?) {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            try {
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
                // The WebView may already have been torn down after cancellation.
            }
            if (continuation.isActive) continuation.resume(value)
        }

        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                try {
                    webView.evaluateJavascript(JS) { raw ->
                        if (finished) return@evaluateJavascript
                        val payload = try {
                            val decoded = JSONTokener(raw ?: "null").nextValue()
                            decoded as? String ?: ""
                        } catch (_: Exception) {
                            ""
                        }
                        attempts++
                        stableCount = if (payload.isNotBlank() && payload == lastPayload) stableCount + 1 else 0
                        lastPayload = payload

                        when {
                            stableCount >= STABLE_READS_REQUIRED -> {
                                val parsed = try { JSONObject(payload) } catch (_: Exception) { null }
                                finish(parsed)
                            }
                            attempts >= MAX_POLL_ATTEMPTS -> finish(null)
                            else -> handler.postDelayed(this, POLL_INTERVAL_MS)
                        }
                    }
                } catch (_: Exception) {
                    finish(null)
                }
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                handler.removeCallbacks(poll)
                handler.postDelayed(poll, INITIAL_POLL_DELAY_MS)
            }
        }

        continuation.invokeOnCancellation {
            handler.post {
                handler.removeCallbacksAndMessages(null)
                try {
                    webView.stopLoading()
                    webView.destroy()
                } catch (_: Exception) {
                    // Ignore teardown errors during worker cancellation.
                }
            }
        }

        try {
            webView.loadUrl(PAGE)
        } catch (_: Exception) {
            finish(null)
        }
    }

    private fun notifyChange(message: String) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "مراقبة فودافون RED", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("تغيّر في أرقام فودافون RED")
            .setContentText(message.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Notifications are unavailable until the user grants permission.
        }
    }

    companion object {
        const val PREFS = "vf"
        const val PERIODIC_WORK = "vf-watch"
        const val MANUAL_WORK = "vf-manual-check"
        const val CHANNEL_ID = "vf_watch_changes"
        const val NOTIFICATION_ID = 701

        const val PAGE = "https://eshop.vodafone.com.eg/en/lines/red/numbers?channelId=REDPlanAR&c_id=DACS0335&c_medium=PPC&c_name=REDPlanAR&c_source=Search&c_term=REDPlanAR&c_type=Anonymous"

        private const val SCRAPE_TIMEOUT_MS = 110_000L
        private const val INITIAL_POLL_DELAY_MS = 2_000L
        private const val POLL_INTERVAL_MS = 1_500L
        private const val MAX_POLL_ATTEMPTS = 55
        private const val STABLE_READS_REQUIRED = 2
        private const val MAX_HISTORY_ITEMS = 40

        // #vf-lines-p هو المصدر الأساسي المطلوب لقيمة Number of Lines.
        // .lines-numbers يظل محددًا احتياطيًا للتوافق مع بنية الصفحة السابقة.
        const val JS = """(function(){
          function asciiDigits(value){
            return String(value == null ? '' : value)
              .replace(/[٠-٩]/g, function(ch){ return String(ch.charCodeAt(0) - 1632); })
              .replace(/[۰-۹]/g, function(ch){ return String(ch.charCodeAt(0) - 1776); })
              .replace(/[٬]/g, ',');
          }
          function cleanText(el){
            if(!el) return '';
            var raw = el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
            return asciiDigits(raw).replace(/\s+/g,' ').trim();
          }
          function parseCounterText(raw, afterLabelOnly){
            var text = asciiDigits(raw).replace(/\s+/g,' ').trim();
            if(!text) return null;
            var label = /(?:number\s+of\s+lines|عدد\s+الخطوط)/i;
            var labelMatch = label.exec(text);
            if(labelMatch){
              var after = text.slice(labelMatch.index + labelMatch[0].length);
              var afterValues = after.match(/\d[\d,]*/g) || [];
              if(afterValues.length){ text = after; }
              else if(afterLabelOnly){
                var before = text.slice(0, labelMatch.index);
                var beforeValues = before.match(/\d[\d,]*/g) || [];
                if(beforeValues.length === 1) text = before;
                else return null;
              }
            } else if(afterLabelOnly) {
              return null;
            }
            var pair = text.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)/);
            var values = text.match(/\d[\d,]*/g) || [];
            function asInt(v){ return parseInt(String(v).replace(/,/g,''),10); }
            var mode = 'single', loaded, total, count;
            if(pair){
              loaded = asInt(pair[1]);
              total = asInt(pair[2]);
              count = total;
              mode = 'pair';
            } else if(values.length){
              count = asInt(values[values.length - 1]);
              loaded = count;
              total = count;
            } else return null;
            if(!Number.isFinite(count) || count < 0) return null;
            return {count:count, loaded:loaded, total:total, mode:mode};
          }

          var selectors = [
            '#vf-lines-p',
            '[data-testid="vf-lines-p"]',
            '[data-cy="vf-lines-p"]',
            '.vf-lines-p',
            'vf-lines-p',
            '[id*="vf-lines-p"]',
            '[data-testid*="lines"]',
            '.lines-numbers'
          ];
          var counter = null;
          var counterSource = '';
          for(var i=0; i<selectors.length; i++){
            try {
              counter = document.querySelector(selectors[i]);
              if(counter){ counterSource = selectors[i]; break; }
            } catch(e) {}
          }

          var parsed = counter ? parseCounterText(cleanText(counter), false) : null;
          if(!parsed && counter){
            var attrValue = counter.getAttribute('data-value') || counter.value || counter.getAttribute('aria-label') || '';
            parsed = parseCounterText(attrValue, false);
          }

          // Fallback: locate the visible label itself, then inspect only its adjacent value/container.
          // This avoids accidentally treating phone numbers elsewhere on the page as the counter.
          if(!parsed){
            var labelPattern = /^(?:number\s+of\s+lines|عدد\s+الخطوط)(?:\s*[:：-]?\s*[\d,]+(?:\s*\/\s*[\d,]+)?)?$/i;
            var leaves = document.querySelectorAll('body *');
            for(var j=0; j<leaves.length && !parsed; j++){
              var el = leaves[j];
              if(el.children && el.children.length) continue;
              var labelText = cleanText(el);
              if(!labelPattern.test(labelText)) continue;
              parsed = parseCounterText(labelText, true);
              if(parsed){ counterSource = 'label-text'; break; }
              var adjacent = [el.nextElementSibling, el.parentElement, el.parentElement && el.parentElement.nextElementSibling];
              for(var k=0; k<adjacent.length && !parsed; k++){
                var candidate = adjacent[k];
                if(!candidate) continue;
                parsed = parseCounterText(cleanText(candidate), false);
                if(parsed){ counterSource = 'label-adjacent'; break; }
              }
            }
          }
          if(!parsed){
            var bodyText = cleanText(document.body).toLowerCase();
            if(/captcha|access denied|cloudflare|حدث خطأ|يرجى المحاولة|يرجى المحاوله/.test(bodyText)){
              return JSON.stringify({error:'تعذّرت قراءة صفحة فودافون: ظهرت رسالة خطأ أو خطوة تحقق بدل بيانات العداد.'});
            }
            return '';
          }

          function onlyDigits(value){ return asciiDigits(value).replace(/\D/g,''); }
          var phoneNumbers = [];
          document.querySelectorAll('.msisdn-item p, .msisdn-item').forEach(function(el){
            var digits = onlyDigits(cleanText(el));
            if(digits.length >= 10 && digits.length <= 15) phoneNumbers.push(digits);
          });
          return JSON.stringify({
            count: parsed.count,
            loaded: parsed.loaded,
            total: parsed.total,
            mode: parsed.mode,
            source: counterSource || 'label-fallback',
            numbers: Array.from(new Set(phoneNumbers))
          });
        })()"""
    }
}
